# CHANGELOG MODULE SUBVENTIONS POUR [DOLIBARR ERP CRM](https://www.dolibarr.org)

## 1.0

- Gestion des subventions, demandes de financements, financeurs et paiements
- Possibilité d'ajouter des documents : demande, notification, convention, bilan, etc.
- Suivi des différents statuts : non déposé, déposé, accepté, refusé, financé, bilan déposé

- Statistiques par année, financeurs et groupe de financeurs
- [Module Projets]  Possibilité d'ajouter les subventions à la vue d'ensemble
- [Module Tiers] Ajout d'un onglet au sein de la fiche tiers des projets